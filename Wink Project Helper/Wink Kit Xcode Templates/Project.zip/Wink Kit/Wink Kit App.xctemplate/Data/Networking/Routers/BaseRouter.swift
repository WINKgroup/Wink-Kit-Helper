//
//  BaseRouter.swift
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Alamofire
import WinkKit

/** Base router contains boilerplate code that can be used by conforming enum.
 You change the base router to make every changes affect all routers, like base url or
 headers.
 However, a typical implementation of a "concrete" router of a user
 (login, logout, registration) would be something like:

        enum UserRouter: BaseRouter, URLRequestConvertible {
            case login(email: String, password: String)
 
            var method: HTTPMethod {
                switch self {
                case .login:
                    return .post
            }
 
            var path: String {
                switch self {
                case .login:
                    return "users/login/"
                }
            }
 
            var encoding: ParameterEncoding {
                switch self {
                default:
                    return URLEncoding.default
                }
            }
 
            // MARK: URLRequestConvertible
 
            func asURLRequest() throws -> URLRequest {
                var params: [String : Any]?
                switch self {
                case let .login(email, password):
                    params = ["username" : email, "password" : password]
                }
 
                return try createRequest(params: params)
            }
        }
*/
protocol BaseRouter {
    var method: HTTPMethod { get }
    var path: String { get }
    var encoding: ParameterEncoding { get }
}

extension BaseRouter {
    
    var encoding: ParameterEncoding {
        return URLEncoding.default
    }
    
    var baseURL: URL {
        return URL(string: <#https://www.myserver.com/api/v1/#>)!
    }
    
    var headers: HTTPHeaders {
        var contentType = "application/json"
        if encoding is URLEncoding {
            contentType = "application/x-www-form-urlencoded"
        }
        
        var dict: HTTPHeaders = ["Content-Type" : contentType]
        
        // TODO: Change headers based on your server implementation
        
        return dict
    }

}

extension BaseRouter where Self : URLRequestConvertible {
    func createRequest(params: [String : Any]? = nil) throws -> URLRequest {
        var request = try URLRequest(url: baseURL.appendingPathComponent(path), method: method, headers: headers)
        if let params = params {
            request = try encoding.encode(request, with: params)
        }
        
        Log.debug(tag: BaseRouter.self, items: request, "params: \(String(describing: params))", "headers: \(String(describing: headers))")
        return request
    }
}
