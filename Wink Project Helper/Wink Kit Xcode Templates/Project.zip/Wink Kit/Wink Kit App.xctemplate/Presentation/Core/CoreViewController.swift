//
//  CoreViewController.swift
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import WinkKit

/// The base view controller of the whole project. Always override this one when you create a new view controller
/// to inherit the MVP feature of `WinkKit` and some common features.
class CoreViewController<P>: WKViewController<P> where P: WKGenericViewControllerPresenter {
    
    // - MARK: Properties
    
    /// The name of the storyboard in which the view controller has been created. Needed to use WinkKit static instantiation.
    override class var storyboardName: String? {
        return Storybaord.main.name
    }
    
    /// The scroll view auto handled by this view controller.
    private(set) var autoHandledScrollView: UIScrollView?
    
    // - MARK: Keyboard handling
    
    /// Method that handle the keyboard appearing. You can override this method to do additional stuff, but you should call super
    /// to make sure scroll view works good.
    @objc func keyboardWillShow(notification: Notification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
            autoHandledScrollView?.contentInset = contentInsets
            autoHandledScrollView?.scrollIndicatorInsets = contentInsets
        }
    }
    
    /// Method that handle the keyboard disappearing. You can override this method to do additional stuff, but you should call super
    /// to make sure scroll view works good.
    @objc func keyboardWillHide(notification: Notification) {
        autoHandledScrollView?.contentInset = .zero
        autoHandledScrollView?.scrollIndicatorInsets = .zero
    }
    
    deinit {
        removeKeyboardObservers()
        Log.debug(tag: self, items: "Destroying...") // useful to make sure view controllers are destroyed.
    }
    
    // - MARK: Internal/overridable methods
    
    /// Set a scroll view make it auto-scroll when keyboard appear. This method will add observers to observe `NSNotification.Name.UIKeyboardWillShow` and
    /// `NSNotification.Name.UIKeyboardWillHide`.
    /// Useful if you have text fields in a scroll view.
    func setAutoHandledScrollView(_ scrollView: UIScrollView?) {
        self.autoHandledScrollView = scrollView
        if scrollView != nil {
            addKeyboardObservers()
        } else {
            removeKeyboardObservers()
        }
    }
    
    func addKeyboardObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func removeKeyboardObservers() {
        NotificationCenter.default.removeObserver(self, name: Notification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.UIKeyboardWillHide, object: nil)
    }
    
}


