//
//  Theme.swift
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

extension UIColor {
    // Put here all colors that needs to be used programmatically
}

extension UIImage {
    // Put here all images that needs to be used programmatically
}

class Theme {
    
    private init() {}
    
    /// Setup all appearence of the app, called in AppDelegate.
    static func setupAppearence() {
        // Example:
        // UIApplication.shared.windows.forEach { w in
        //    w.tintColor = .red
        //    w.backgroundColor = .white
        // }
    }
}
