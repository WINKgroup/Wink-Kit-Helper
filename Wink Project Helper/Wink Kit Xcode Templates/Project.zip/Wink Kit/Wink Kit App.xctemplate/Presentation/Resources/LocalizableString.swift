//
//  LocalizableString.swift
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

/// Enum that contains all localizable strings of the project. With enum, we avoid copy paste plain string in the whole project
enum LocalizableString: String {
    
    // Put here all strings
    
    /// The localized value of this case.
    var value: String {
        return self.rawValue.so_localized()
    }
    
    func formattedWith(parameters: [String]) -> String {
        return self.rawValue.so_localized().so_formatted(parameters: parameters)
    }

}
