//
//  Storybaord.swift
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

/// Enum that maps all storyboard of the application.
enum Storybaord: String {
    
    case main = "Main"
    
    /// The name must match the file name of the storyboard.
    var name: String {
        return rawValue
    }
    
    /// Returns a new instance of the storyboard.
    var instance: UIStoryboard {
        return UIStoryboard(name: name, bundle: nil)
    }
    
}

