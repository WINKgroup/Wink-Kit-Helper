//___FILEHEADER___

import WinkKit

class ___VARIABLE_UseCaseName___ViewController: WKViewController<___VARIABLE_UseCaseName___Presenter> {
    
    override class var storyboardName: String? {
        return <#storyboardName#>
    }
    
}

extension ___VARIABLE_UseCaseName___ViewController: ___VARIABLE_UseCaseName___View {
    
}
